from django.contrib import admin
from .models import Genero, CreepyPasta ,MensajesAdmi2
# Register your models here.
admin.site.register(Genero)
admin.site.register(CreepyPasta)
admin.site.register(MensajesAdmi2)
