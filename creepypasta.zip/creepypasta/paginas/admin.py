from django.contrib import admin
from .models import genero, creepypasta ,mensajesadmi2
# Register your models here.
admin.site.register(genero)
admin.site.register(creepypasta)
admin.site.register(mensajesadmi2)
